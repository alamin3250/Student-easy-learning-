import 'package:flutter/material.dart';

void main() => runApp(const StudentEasyLearningApp());

class StudentEasyLearningApp extends StatelessWidget {
  const StudentEasyLearningApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Student Easy Learning',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const HomePage(),
    );
  }
}

class Subject {
  final String name;
  final IconData icon;
  final List<Chapter> chapters;
  const Subject(this.name, this.icon, this.chapters);
}

class Chapter {
  final String title;
  final String note;
  final List<Question> questions;
  final List<Mcq> mcqs;
  const Chapter(this.title, this.note, this.questions, this.mcqs);
}

class Question {
  final String question, answer;
  const Question(this.question, this.answer);
}

class Mcq {
  final String question;
  final List<String> options;
  final int answer;
  const Mcq(this.question, this.options, this.answer);
}

const mathChapter = Chapter(
  'সংখ্যা পরিচিতি',
  'সংখ্যা গণিতের একটি মৌলিক বিষয়। ১, ২, ৩, ৪, ৫ ইত্যাদি প্রাকৃতিক সংখ্যার উদাহরণ। নিয়ম বুঝে নিয়মিত অনুশীলন করলে গণিত শেখা সহজ হয়।',
  [
    Question('প্রাকৃতিক সংখ্যা কী?', '১, ২, ৩, ৪, ... এভাবে গণনার কাজে ব্যবহৃত সংখ্যাগুলোকে প্রাকৃতিক সংখ্যা বলা হয়।'),
    Question('গণিত ভালো করার সহজ উপায় কী?', 'নিয়ম বুঝে নিয়মিত অনুশীলন করা এবং ভুলগুলো সংশোধন করা।'),
  ],
  [
    Mcq('নিচের কোনটি প্রাকৃতিক সংখ্যা?', ['০', '৫', '-২', '-৫'], 1),
    Mcq('২ + ৩ = কত?', ['৪', '৫', '৬', '৭'], 1),
  ],
);

final subjects = [
  Subject('বাংলা', Icons.menu_book, [mathChapter]),
  Subject('ইংরেজি', Icons.language, [
    Chapter('Parts of Speech',
      'Parts of Speech হলো বাক্যে শব্দের কাজ অনুযায়ী শব্দের শ্রেণিবিভাগ। যেমন: Noun, Pronoun, Verb, Adjective।',
      [
        Question('Noun কী?', 'যে শব্দ দ্বারা ব্যক্তি, বস্তু, স্থান বা ধারণার নাম বোঝায় তাকে Noun বলে।'),
        Question('Verb কী?', 'যে শব্দ দ্বারা কাজ করা বা হওয়া বোঝায় তাকে Verb বলে।'),
      ],
      [
        Mcq('Which one is a noun?', ['Run', 'Beautiful', 'Book', 'Quickly'], 2),
        Mcq('Which one is a verb?', ['Eat', 'Boy', 'Good', 'Slowly'], 0),
      ]),
  ]),
  Subject('গণিত', Icons.calculate, [mathChapter]),
  Subject('বিজ্ঞান', Icons.science, [
    Chapter('জীব ও পরিবেশ',
      'জীব পরিবেশের বিভিন্ন উপাদানের সঙ্গে সম্পর্ক রেখে বেঁচে থাকে। উদ্ভিদ, প্রাণী ও অণুজীব জীবজগতের অংশ।',
      [
        Question('পরিবেশ কী?', 'জীবকে ঘিরে থাকা জীব ও জড় উপাদানের সমষ্টিকে পরিবেশ বলা হয়।'),
        Question('উদ্ভিদ কেন গুরুত্বপূর্ণ?', 'উদ্ভিদ খাদ্য, অক্সিজেন ও পরিবেশের ভারসাম্য রক্ষায় গুরুত্বপূর্ণ।'),
      ],
      [
        Mcq('উদ্ভিদ প্রধানত কী উৎপন্ন করে?', ['অক্সিজেন', 'লোহা', 'প্লাস্টিক', 'কাচ'], 0),
        Mcq('জীবের চারপাশের উপাদানের সমষ্টিকে কী বলে?', ['শব্দ', 'পরিবেশ', 'আলো', 'তাপ'], 1),
      ]),
  ]),
];

const classes = ['৬', '৭', '৮', '৯', '১০'];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selectedClass = 0;
  String search = '';

  @override
  Widget build(BuildContext context) {
    final filtered = subjects.where((s) =>
      search.isEmpty || s.name.contains(search)).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Student Easy Learning'), centerTitle: true),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF4F46E5), Color(0xFF7C3AED)]),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('শিখুন সহজে 📚', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('বই, নোট, প্রশ্ন ও MCQ — সব এক জায়গায়।', style: TextStyle(color: Colors.white70)),
            ]),
          ),
          const SizedBox(height: 16),
          TextField(
            onChanged: (v) => setState(() => search = v.trim()),
            decoration: InputDecoration(
              hintText: 'বিষয় খুঁজুন...',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
            ),
          ),
          const SizedBox(height: 18),
          const Text('আপনার শ্রেণি', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SizedBox(
            height: 48,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: classes.length,
              itemBuilder: (_, i) => Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text('শ্রেণি ${classes[i]}'),
                  selected: selectedClass == i,
                  onSelected: (_) => setState(() => selectedClass = i),
                ),
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('বিষয়সমূহ', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          ...filtered.map((subject) => Card(
            child: ListTile(
              leading: CircleAvatar(child: Icon(subject.icon)),
              title: Text(subject.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${subject.chapters.length}টি অধ্যায়'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => SubjectPage(subject: subject, className: classes[selectedClass]),
              )),
            ),
          )),
        ],
      ),
    );
  }
}

class SubjectPage extends StatelessWidget {
  final Subject subject;
  final String className;
  const SubjectPage({super.key, required this.subject, required this.className});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('${subject.name} • শ্রেণি $className')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ...subject.chapters.asMap().entries.map((e) => Card(
          child: ListTile(
            leading: CircleAvatar(child: Text('${e.key + 1}')),
            title: Text(e.value.title),
            subtitle: const Text('নোট • প্রশ্ন • MCQ'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => ChapterPage(chapter: e.value),
            )),
          ),
        )),
      ],
    ),
  );
}

class ChapterPage extends StatelessWidget {
  final Chapter chapter;
  const ChapterPage({super.key, required this.chapter});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(chapter.title)),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        menu(context, Icons.notes, 'নোট', 'অধ্যায়ের নোট পড়ুন',
          () => Navigator.push(context, MaterialPageRoute(builder: (_) => NotesPage(chapter: chapter)))),
        menu(context, Icons.question_answer, 'প্রশ্ন ও উত্তর', 'গুরুত্বপূর্ণ প্রশ্ন অনুশীলন করুন',
          () => Navigator.push(context, MaterialPageRoute(builder: (_) => QuestionsPage(chapter: chapter)))),
        menu(context, Icons.quiz, 'MCQ পরীক্ষা', 'নিজেকে যাচাই করুন',
          () => Navigator.push(context, MaterialPageRoute(builder: (_) => McqPage(chapter: chapter)))),
      ],
    ),
  );

  Widget menu(BuildContext context, IconData icon, String title, String sub, VoidCallback tap) => Card(
    child: ListTile(
      leading: CircleAvatar(child: Icon(icon)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(sub),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: tap,
    ),
  );
}

class NotesPage extends StatelessWidget {
  final Chapter chapter;
  const NotesPage({super.key, required this.chapter});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('নোট')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Text(chapter.title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      const SizedBox(height: 18),
      Text(chapter.note, style: const TextStyle(fontSize: 17, height: 1.7)),
    ]),
  );
}

class QuestionsPage extends StatelessWidget {
  final Chapter chapter;
  const QuestionsPage({super.key, required this.chapter});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('প্রশ্ন ও উত্তর')),
    body: ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: chapter.questions.length,
      itemBuilder: (_, i) => Card(
        child: ExpansionTile(
          title: Text('${i + 1}. ${chapter.questions[i].question}'),
          childrenPadding: const EdgeInsets.all(16),
          children: [Align(
            alignment: Alignment.centerLeft,
            child: Text('উত্তর: ${chapter.questions[i].answer}', style: const TextStyle(fontSize: 16)),
          )],
        ),
      ),
    ),
  );
}

class McqPage extends StatefulWidget {
  final Chapter chapter;
  const McqPage({super.key, required this.chapter});
  @override
  State<McqPage> createState() => _McqPageState();
}

class _McqPageState extends State<McqPage> {
  int current = 0, score = 0;
  int? selected;

  void choose(int i) {
    if (selected != null) return;
    setState(() {
      selected = i;
      if (i == widget.chapter.mcqs[current].answer) score++;
    });
  }

  void next() {
    if (current == widget.chapter.mcqs.length - 1) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          title: const Text('পরীক্ষা শেষ 🎉'),
          content: Text('আপনার স্কোর: $score / ${widget.chapter.mcqs.length}'),
          actions: [TextButton(
            onPressed: () { Navigator.pop(context); Navigator.pop(context); },
            child: const Text('শেষ করুন'),
          )],
        ),
      );
    } else {
      setState(() { current++; selected = null; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.chapter.mcqs[current];
    return Scaffold(
      appBar: AppBar(title: const Text('MCQ পরীক্ষা')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          LinearProgressIndicator(value: (current + 1) / widget.chapter.mcqs.length),
          const SizedBox(height: 20),
          Text('প্রশ্ন ${current + 1} / ${widget.chapter.mcqs.length}'),
          const SizedBox(height: 12),
          Text(q.question, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 18),
          ...q.options.asMap().entries.map((e) => Card(
            child: ListTile(
              leading: CircleAvatar(child: Text(String.fromCharCode(65 + e.key))),
              title: Text(e.value),
              trailing: selected != null && e.key == q.answer
                ? const Icon(Icons.check_circle)
                : selected != null && e.key == selected
                  ? const Icon(Icons.cancel) : null,
              onTap: () => choose(e.key),
            ),
          )),
          const SizedBox(height: 10),
          FilledButton(
            onPressed: selected == null ? null : next,
            child: Text(current == widget.chapter.mcqs.length - 1 ? 'ফলাফল দেখুন' : 'পরের প্রশ্ন'),
          ),
        ],
      ),
    );
  }
}
