# Student Easy Learning — Flutter

Flow: Home → Class → Subject → Chapter → Notes/Questions/MCQ

## Run
flutter pub get
flutter run

## Android APK
flutter build apk --release

The included educational content is demo/placeholder content. Replace it with your own lawful notes and book content.
